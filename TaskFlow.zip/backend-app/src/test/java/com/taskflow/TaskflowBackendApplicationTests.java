package com.taskflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskflowBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
