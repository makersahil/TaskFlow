package com.taskflow.dto;

public record TaskAssigneeResponse(
    Long id,
    String email
) {
}
