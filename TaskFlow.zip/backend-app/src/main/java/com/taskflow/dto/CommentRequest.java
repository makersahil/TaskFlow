package com.taskflow.dto;

public record CommentRequest(
    String content
) {
}
