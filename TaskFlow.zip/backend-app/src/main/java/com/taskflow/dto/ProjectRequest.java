package com.taskflow.dto;

public record ProjectRequest(String name) {
}
