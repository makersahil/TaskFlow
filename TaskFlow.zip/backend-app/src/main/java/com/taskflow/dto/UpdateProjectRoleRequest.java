package com.taskflow.dto;

public record UpdateProjectRoleRequest(
    String role
) {
}
