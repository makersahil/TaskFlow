package com.taskflow.dto;

public record ProjectResponse(Long id, String name, String ownerEmail, String role) {
}
