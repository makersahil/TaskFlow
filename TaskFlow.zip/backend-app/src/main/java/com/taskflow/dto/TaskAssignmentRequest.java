package com.taskflow.dto;

public record TaskAssignmentRequest(
    String assigneeEmail
) {
}
